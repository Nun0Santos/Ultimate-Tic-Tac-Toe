#include "globals.h"

void welcome();
char
void initializer();