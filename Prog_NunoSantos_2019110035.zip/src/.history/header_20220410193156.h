#include "globals.h"

void welcome();
char menu();
void initializer();