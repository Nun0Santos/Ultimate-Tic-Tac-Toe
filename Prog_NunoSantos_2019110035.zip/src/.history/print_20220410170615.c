#include "header.h"


void welcome(){
    printf("");
    printf("");
    printf("");
    printf("");
    printf("");
    printf("");
}