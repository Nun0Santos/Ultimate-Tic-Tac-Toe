#include "globals.h"

void welcome();
void initializer();