#include "globals.h"

void welcome();
void inicia