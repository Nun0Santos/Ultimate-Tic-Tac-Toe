#include "header.h"


void welcome(){
    printf("\n   _    _ _ _   _                 _  \n");      
    print("\n   | |  | | | | (_)               | |  \n");     
    printf("\n  | |  | | | |_ _ _ __ ___   __ _| |_ ___  \n");
    printf("\n  | |  | | | __| | '_ ` _ \ / _` | __/ _ \ \n");
    printf("\n  | |__| | | |_| | | | | | | (_| | ||  __/ \n");
    printf("\n  \____/|_|\__|_|_| |_| |_|\__,_|\__\___| \n");
                                          
                                          


    printf("");
    printf("");
    printf("");
    printf("");
    printf("");
}