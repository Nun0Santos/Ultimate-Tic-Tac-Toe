#include "globals.h"

void welcome();
void inici