#include "header.h"


int menu(){
    welcome();
    int op;
    printf("Choice one option:\n");
    printf(" 1-Play\n"
            "2-Help\n"
            "3-Exit\n");
    do{
        printf("Option: ");
        scanf("%d",&op);
        if(op != 1 && op !)
    }

}