#include "header.h"
#include "globals.h"

int menu(){
    w
    int op;


}