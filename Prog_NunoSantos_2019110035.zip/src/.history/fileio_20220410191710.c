#include "header.h"
#include "globals.h"

int menu(){
    welcome();
    int op;


}