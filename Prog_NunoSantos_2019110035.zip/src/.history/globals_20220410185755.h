#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct board{
    int jogadador;
    char miniBoard[][][];

}