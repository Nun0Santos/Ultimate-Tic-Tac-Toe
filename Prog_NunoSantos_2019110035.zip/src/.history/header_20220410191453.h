#include "globals.h"

void welcome();
int menu():
void initializer();