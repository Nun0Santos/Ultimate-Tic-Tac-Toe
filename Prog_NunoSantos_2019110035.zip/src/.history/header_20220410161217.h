#include "globals.h"

void welcome();
