#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct Board{
    int jogadador;
    
    char internalBoard[9][3][3];
    char externalBoard[3][3];
}Board;